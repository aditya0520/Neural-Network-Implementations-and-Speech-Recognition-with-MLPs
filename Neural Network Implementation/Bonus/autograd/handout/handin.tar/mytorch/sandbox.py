"""
Feel free to use this file as you wish. It is intended for you
to be able to debug your implementation by creating mini-tests
yourself as you progress through the assignment and finish the 
various components.

Be mindful of the imports - you may find that you need to import
more modules.
"""

import numpy as np
import torch

# import nn as nn
# from autograd_engine import Autograd

if __name__ == "__main__":
    
    pass
